import { IForm } from "../interface/form.interface";

export const costCodeformatFormConfig: IForm = {
    addFormTitle: 'Add Cost Code Format',
    editFormTitle: 'Edit Cost Code Format',
    saveBtnTitle: 'Save Changes',
    cancelBtnTitle: 'Cancel',
    modalSize: 'sm',
    formControls: [
        {
            "name": "costcodeanind",
            "label": "Format Option",
            "value": "", 
            "placeholder": "",
            //"class": "pconfig col-md-6",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Format Option is required."
                }               
            ]
        },

        {
            "name": "costcodealign",
            "label": "Alignment",
            "value": "", 
            "placeholder": "Alignment",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Department Name is required."
                },
                {
                    "validatorName": "maxlength",
                    "maxLength": 50,
                    "message": "Maximum length should be 50 characters."
                },
                {
                    "validatorName": "pattern",
                    "pattern": "^[a-zA-Z0-9 ]+$",
                    "message": "Only alphanumeric characters are allowed."
                }
            ]
        },

        {
            "name": "Number",
            "label": "Number",
            "value": "", 
            "placeholder": "Number",
            "class": "pconfig col-md-3 text-right",
            "type": "label",
            "dataType": "",
            "tooltip": "",
            "validators": []
          },

          {
            "name": "Start",
            "label": "Start",
            "class": "pconfig col-md-3 text-right",
            "type": "label",
            "dataType": "",
            "tooltip": "",
            "validators": []
          },

          {
            "name": "End",
            "label": "End",
            "class": "pconfig col-md-3 text-right",
            "type": "label",
            "dataType": "",
            "tooltip": "",
            "validators": []
          },

          {
            "name": "Description",
            "label": "Description",
            "class": "pconfig col-md-3 text-right",
            "type": "label",
            "dataType": "",
            "tooltip": "",
            "validators": []
          },

    
        {
            "name": "compccsortfacet1no",
            "label": "Facet 1:",
            "value": "", 
            "placeholder": "Cost Code Facet 1 Number",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^[0-9]+$",
                    "message": "Only digits are allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet1start",
            "label": " ",
            "value": "", 
            "placeholder": "Cost Code Facet 1 Start",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet1end",
            "label": "",
            "value": "", 
            "placeholder": "Cost Code Facet 1 End",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet1descn",
            "label": " ",
            "value": "", 
            "placeholder": "Cost Code Facet 1 Description",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "maxlength",
                    "maxLength": 12,
                    "message": "Maximum length should be 12 characters."
                },
            ]
        },

        {
            "name": "compccsortfacet2no",
            "label": "Facet 2:",
            "value": "", 
            "placeholder": "Number",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^[0-9]+$",
                    "message": "Only digits are allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet2start",
            "label": "",
            "value": "", 
            "placeholder": "Start",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet2end",
            "label": "",
            "value": "", 
            "placeholder": "End",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet2descn",
            "label": "",
            "value": "", 
            "placeholder": "Description",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "maxlength",
                    "maxLength": 12,
                    "message": "Maximum length should be 12 characters."
                },
            ]
        },

        {
            "name": "compccsortfacet3no",
            "label": "Facet 3:",
            "value": "", 
            "placeholder": "Number",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^[0-9]+$",
                    "message": "Only digits are allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet3start",
            "label": "",
            "value": "", 
            "placeholder": "Start",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet3end",
            "label": "",
            "value": "", 
            "placeholder": "End",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet3descn",
            "label": "",
            "value": "", 
            "placeholder": "Description",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "maxlength",
                    "maxLength": 12,
                    "message": "Maximum length should be 12 characters."
                },
            ]
        },

        {
            "name": "compccsortfacet4no",
            "label": "Facet 4:",
            "value": "", 
            "placeholder": "Number",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^[0-9]+$",
                    "message": "Only digits are allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet4start",
            "label": "",
            "value": "", 
            "placeholder": "Start",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet4end",
            "label": "",
            "value": "", 
            "placeholder": "End",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet4descn",
            "label": "",
            "value": "", 
            "placeholder": "Description",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "maxlength",
                    "maxLength": 12,
                    "message": "Maximum length should be 12 characters."
                },
            ]
        },

        {
            "name": "compccsortfacet5no",
            "label": "Facet 5:",
            "value": "", 
            "placeholder": "Number",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^[0-9]+$",
                    "message": "Only digits are allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet5start",
            "label": "",
            "value": "", 
            "placeholder": "Start",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet5end",
            "label": "",
            "value": "", 
            "placeholder": "End",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet5descn",
            "label": "",
            "value": "", 
            "placeholder": "Description",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "maxlength",
                    "maxLength": 12,
                    "message": "Maximum length should be 12 characters."
                },
            ]
        },

        {
            "name": "compccsortfacet6no",
            "label": "Facet 6:",
            "value": "", 
            "placeholder": "Number",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^[0-9]+$",
                    "message": "Only digits are allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet6start",
            "label": "",
            "value": "", 
            "placeholder": "Start",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet6end",
            "label": "",
            "value": "", 
            "placeholder": "End",
            "class": "pconfig col-md-3",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "pattern",
                    "pattern": "^([0-9]|[1][0-9])$",
                    "message": "Only digits in the range 1 to 20 allowed."
                }
            ]
        },

        {
            "name": "compccsortfacet6descn",
            "label": "",
            "value": "", 
            "placeholder": "Description",
            "class": "pconfig col-md-3 text-right",
            "type": "text",
            "dataType" : "int",
            "tooltip" : "",
            "validators": [
               
                {
                    "validatorName": "maxlength",
                    "maxLength": 12,
                    "message": "Maximum length should be 12 characters."
                },
            ]
        },


    ],

}