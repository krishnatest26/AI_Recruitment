import { IForm } from "../interface/form.interface";

export const departmentFormConfig: IForm = {
    addFormTitle: 'Add Department',
    editFormTitle: 'Edit Department',
    saveBtnTitle: 'Save Changes',
    cancelBtnTitle: 'Cancel',
    modalSize: 'sm',
    formControls: [
        {
            "name": "departmentnumber",
            "label": "Department Reference",
            "value": "",
            "placeholder": "Department Reference",
            "class": "col-md-12",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Department Reference is required."
                },
                {
                    "validatorName": "maxlength",
                    "maxLength": 4,
                    "message": "Maximum length should be 4 characters."
                },
                {
                    "validatorName": "pattern",
                    "pattern": "^[0-9]+$",
                    "message": "Only numeric characters are allowed."
                }
            ]
        },

        {
            "name": "departmentdescription",
            "label": "Department Name",
            "value": "",
            "placeholder": "Department Name",
            "class": "col-md-12",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 50 character alphanumeric description",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Department Name is required."
                },
                {
                    "validatorName": "maxlength",
                    "maxLength": 50,
                    "message": "Maximum length should be 50 characters."
                },
                {
                    "validatorName": "pattern",
                    "pattern": "^[a-zA-Z0-9 ]+$",
                    "message": "Only alphanumeric characters are allowed."
                }
            ]
        },
    ],

}
