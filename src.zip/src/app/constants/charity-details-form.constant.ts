import { IForm } from "../interface/form.interface";

export const charityDetailsFormConfig: IForm = {
    addFormTitle: 'Add Charity Details',
    editFormTitle: 'Edit Charity Details',
    saveBtnTitle: 'Save Changes',
    cancelBtnTitle: 'Cancel',
    modalSize: 'sm',
    formControls: [
        {
            "name": "compagencyname",
            "label": "Agency Name",
            "value": "", 
            "placeholder": "Agency Name",
            "class": "col-md-12",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Agency Name is required."
                },
                {
                    "validatorName": "maxlength",
                    "maxLength": 30,
                    "message": "Maximum length should be 30 characters."
                },
                {
                    "validatorName": "pattern",
                    "pattern": "^[a-zA-Z0-9 ]+$",
                    "message": "Only alphanumeric characters are allowed."
                }
            ]
        },

        {
            "name": "compagencyref",
            "label": "Agency Reference",
            "value": "", 
            "placeholder": "Agency Reference",
            "class": "col-md-12",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Agency Reference is required."
                },
                {
                    "validatorName": "maxlength",
                    "maxLength": 18,
                    "message": "Maximum length should be 18 characters."
                },
                {
                    "validatorName": "pattern",
                    "pattern": "^[a-zA-Z0-9 ]+$",
                    "message": "Only alphanumeric characters are allowed."
                }
            ]
        },

        {
            "name": "compdedno",
            "label": "Deduction Number",
            "value": "", 
            "placeholder": "Deduction Number",
            "class": "col-md-12",
            "type": "dropdown",
            "dataType" : "string",
            "tooltip" : "",
            "options": [
                {value: 'E7660823-7E43-4D1E-95E2-3BE74B099231', label: '01'},
                {value: '06BB04A1-D9C4-4614-80B5-0B401721FD1E', label: '02'},
                {value: '853CCF7D-5B64-46F3-A791-52416E90A443', label: '03'},
                {value: '24BF033E-514A-4EF0-A1EA-29A737E3C292', label: '04'}
            ],
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Deduction Number is required."
                }
            ]
        },
    ],

}