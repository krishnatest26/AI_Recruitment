import { IForm } from "../interface/form.interface";

export const payrollSettingFormConfig: IForm = {
    addFormTitle: '',
    editFormTitle: '',
    saveBtnTitle: '',
    cancelBtnTitle: '',
    modalSize: '',
    formControls: [
        {
            "name": "payrollid",
            "label": "Payroll ID",
            "value": "", 
            "placeholder": "Payroll ID",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Payroll ID is required."
                },
                {
                    "validatorName": "pattern",
                    "pattern": "^[0-9]{6}$",
                    "message": "Payroll ID must be 6 numeric characters."
                }
            ]
        },
        {
            "name": "recalculationrequired",
            "label": "Recalculation Required",
            "value": false, // Assuming it's initially unchecked
            "class": "col-md-6 recalcultaion",
            "type": "checkbox",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
        {
            "name": "companyname",
            "label": "Name",
            "value": "", 
            "placeholder": "Name",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Name is required."
                },
                {
                    "validatorName": "maxlength",
                    "maxLength": 30,
                    "message": "Maximum length should be 30 characters."
                },
                {
                    "validatorName": "pattern",
                    "pattern": "^[a-zA-Z0-9 ]+$",
                    "message": "Only alphanumeric characters are allowed."
                }
            ]
        },
        // Continue adding form controls for other fields based on the provided details...
     
        {
            "name": "freezehmrcdata",
            "label": "Freeze HMRC data on commit",
            "value": false, // Assuming it's initially unchecked
            "class": "col-md-6 freez",
            "type": "checkbox",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
        {
            "name": "companyfrequency",
            "label": "Frequency",
            "value": "", 
            "class": "pconfig col-md-6",
            "type": "dropdown",
            "dataType" : "string",
            "tooltip" : "",
            "options": [ // Assuming options are provided
                { "value": "A", "label": "Annual" },
                { "value": "M", "label": "Monthly" },
                { "value": "Q", "label": "Quarterly" },
                { "value": "W", "label": "Weekly" },
                { "value": "H", "label": "Hourly" },
                { "value": "L", "label": "Lunar" }
            ],
            "validators": [ {
                "validatorName": "required",
                "required": true,
                "message": "Frequency is required."
            }]
        }

        //  {
        //     "name": "companyfrequency",
        //     "label": "Frequency",
        //     "value": "", 
        //     "placeholder": "Frequency",
        //     "class": "pconfig col-md-6",
        //     "type": "text",
        //     "validators": [
        //         {
        //             "validatorName": "required",
        //             "required": true,
        //             "message": "Frequency is required."
        //         },
        //         {
        //             "validatorName": "maxlength",
        //             "maxLength": 50,
        //             "message": "Maximum length should be 50 characters."
        //         },
        //         {
        //             "validatorName": "pattern",
        //             "pattern": "^[a-zA-Z0-9 ]+$",
        //             "message": "Only alphanumeric characters are allowed."
        //         }
        //     ]
        // }
    ],

}
