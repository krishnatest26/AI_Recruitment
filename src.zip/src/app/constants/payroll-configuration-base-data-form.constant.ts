import { IForm } from "../interface/form.interface";

export const payrollSettingBaseDataFormConfig: IForm = {
    addFormTitle: '',
    editFormTitle: '',
    saveBtnTitle: 'Save Changes',
    cancelBtnTitle: '',
    modalSize: '',
    formControls: [ 
        {
            "name": "compaddR1",
            "label": "Address Line 1",
            "value": "", 
            "placeholder": "Address Line 1",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "The First line of the address must be entered."
                }
            ]
        },
        {
            "name": "complocation",
            "label": "Location",
            "value": "", 
            "placeholder": "Location",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
        {
            "name": "compaddR2",
            "label": "Address Line 2",
            "value": "", 
            "placeholder": "Address Line 2",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "The Second line of the address must be entered."
                }
            ]
        },
        {
            "name": "comptype",
            "label": "Pension Payroll",
            "value": "", // Assuming it's initially unchecked
            "class": "pconfig col-md-6",
            "type": "checkbox",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
        {
            "name": "compaddR3",
            "label": "Address Line 3",
            "value": "", 
            "placeholder": "Address Line 3",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
        {
            "name": "compfiscalauth",
            "label": "Fiscal Authority",
            "value": "", 
            "class": "pconfig col-md-6",
            "type": "dropdown",
            "dataType" : "string",
            "tooltip" : "",
            "options": [ // Assuming options are provided
                { "value": "Gibraltar", "label": "Gibraltar" },
                { "value": "Guernsey", "label": "Guernsey" },
                { "value": "I o M", "label": "I o M" },
                { "value": "Jersey", "label": "Jersey" },
                { "value": "ROI", "label": "ROI" },
                { "value": "UK", "label": "UK" }
            ],
            "validators": []
        },
        {
            "name": "compaddR4",
            "label": "Address Line 4",
            "value": "", 
            "placeholder": "Address Line 4",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
        
        {
            "name": "compauditno",
            "label": "Contract Audit No",
            "value": "", 
            "placeholder": "Contract Audit No",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
        {
            "name": "compaddR5",
            "label": "Address Line 5",
            "value": "", 
            "placeholder": "Address Line 5",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
        
        {
            "name": "compbuscat",
            "label": "Business Category",
            "value": "", 
            "class": "pconfig col-md-6",
            "type": "dropdown",
            "dataType" : "string",
            "tooltip" : "",
            "options": [
                { "value": "ACCO", "label": "Accountants & Auditors" },
                { "value": "AGRI", "label": "Agriculture (Includes Market Gardening Forestry Fishing)" },
                { "value": "BANK", "label": "Banking & Finance (Building Socs,Finance Cos,Factoring Cos)" },
                { "value": "BUSS", "label": "Business Services" },
                { "value": "CHAR", "label": "Charities & Religious" },
                { "value": "CHEM", "label": "Chemicals & Plastics" },
                { "value": "TEXT", "label": "Clothing & Textiles Manufacturing" },
                { "value": "COMP", "label": "Computing (Inc Telecoms, ISPs, Hardware Manuf)" },
                { "value": "CONS", "label": "Construction & Civil Engineering" },
                { "value": "DEFE", "label": "Defence" },
                { "value": "EDUC", "label": "Education (Inc. Adult Edu & Nurseries)" },
                { "value": "ELET", "label": "Electrical & Electronic Engineering" },
                { "value": "FOOD", "label": "Food Manufacturing (Inc Brewers, Distillers, Drink & To)" },
                { "value": "GOVT", "label": "Government(Central & Local Services)" },
                { "value": "HOTE", "label": "Hotels & Catering" },
                { "value": "INSU", "label": "Insurance & Investment(Pens Funds,Trusts,Secu Dlrs Brkers)" },
                { "value": "LEGA", "label": "Legal" },
                { "value": "LEIS", "label": "Leisure & Entertaining (Including Sport)" },
                { "value": "MECH", "label": "Mechanical Engineering & Machinery Manufacture" },
                { "value": "MEDI", "label": "Medical(Drs,Dental,Hosptls,Nhs Trusts,Vetinary)" },
                { "value": "MISC", "label": "Miscellaneous" },
                { "value": "MOTO", "label": "Motor(Manufacture & Garage)" },
                { "value": "OMFR", "label": "Other Manufacturing" },
                { "value": "PERS", "label": "Personal Services" },
                { "value": "PHAR", "label": "Pharmaceuticals & Cosmetics" },
                { "value": "PRIN", "label": "Printing & Publishing" },
                { "value": "PROP", "label": "Property" },
                { "value": "RETA", "label": "Retail & Sales" },
                { "value": "RETI", "label": "Retirement & Rest Homes" },
                { "value": "TRAN", "label": "Transport(Freight,Passenger,Rail,Air,Sea)" },
                { "value": "UTIL", "label": "Utilities(Mining,Gas,Nuclear,Electricity,Water,Oil)" },
                { "value": "WHOL", "label": "Wholesale" }
            ],
            "validators": []
        },
        {
            "name": "compaddrcountry",
            "label": "Country",
            "value": "", 
            "placeholder": "Country",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "The Country must be entered."
                }
            ]
        },
        {
            "name": "compstartdate",
            "label": "Start Date",
            "value": "", 
            "class": "pconfig col-md-6",
            "type": "date",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
        {
            "name": "compaddrpostcode",
            "label": "Post Code",
            "value": "", 
            "placeholder": "Post Code",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "The Postcode must be entered."
                }
            ]
        },
        {
            "name": "compenddate",
            "label": "End Date",
            "value": "", 
            "class": "pconfig col-md-6",
            "type": "date",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "greaterThan",
                    "greaterThan": "compstartdate",
                    "message": "End Date must be greater than Start Date."
                }
            ]
        },
        {
            "name": "compmainphone",
            "label": "Main Phone",
            "value": "", 
            "placeholder": "Main Phone",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "A company must have a phone number."
                }
            ]
        },
        {
            "name": "terminated",
            "label": "Terminated",
            "value": false, // Assuming it's initially unchecked
            "class": "col-md-6 terminate",
            "type": "checkbox",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
        {
            "name": "compfaxno",
            "label": "Fax Number",
            "value": "", 
            "placeholder": "Fax Number",
            "class": "pconfig col-md-6",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "",
            "validators": []
        },
    ],
};
