import { IForm } from "../interface/form.interface";

export const controlCalendarsFormConfig: IForm = {
    addFormTitle: 'Add Control Calendar',
    editFormTitle: 'Edit Control Calendar',
    saveBtnTitle: 'Save Changes',
    cancelBtnTitle: 'Cancel',
    modalSize: 'lg',
    formControls: [
        {
            "name": "calno",
            "label": "Payroll Calendar Name",
            "value": "",
            "placeholder": "Payroll Calendar Name",
            "class": "col-md-12 pcname",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Payroll Calendar Name is required."
                },
                {
                    "validatorName": "maxlength",
                    "maxLength": 20,
                    "message": "Maximum length should be 20 characters."
                },
                {
                    "validatorName": "pattern",
                    "pattern": "^[0-9]+$",
                    "message": "Only numeric characters are allowed."
                }
            ]
        },
        {
            "name": "calperd01",
            "label": "Period 01",
            "value": "",
            "placeholder": "Period 01",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": [
                {
                    "validatorName": "required",
                    "required": true,
                    "message": "Period 01 is required."
                },
                {
                    "validatorName": "pattern",
                    "pattern": "^[0-9]+$",
                    "message": "Only numeric characters are allowed."
                }
            ]
        },
        {
            "name": "calperd02",
            "label": "Period 02",
            "value": "",
            "placeholder": "Period 02",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd03",
            "label": "Period 03",
            "value": "",
            "placeholder": "Period 03",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd04",
            "label": "Period 04",
            "value": "",
            "placeholder": "Period 04",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd05",
            "label": "Period 05",
            "value": "",
            "placeholder": "Period 05",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd06",
            "label": "Period 06",
            "value": "",
            "placeholder": "Period 06",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd07",
            "label": "Period 07",
            "value": "",
            "placeholder": "Period 07",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd08",
            "label": "Period 08",
            "value": "",
            "placeholder": "Period 08",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd09",
            "label": "Period 09",
            "value": "",
            "placeholder": "Period 09",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd10",
            "label": "Period 10",
            "value": "",
            "placeholder": "Period 10",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd11",
            "label": "Period 11",
            "value": "",
            "placeholder": "Period 11",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd12",
            "label": "Period 12",
            "value": "",
            "placeholder": "Period 12",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calperd13",
            "label": "Period 13",
            "value": "",
            "placeholder": "Period 13",
            "class": "col-md-2",
            "type": "text",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": []
        },
        {
            "name": "calnotes",
            "label": "Payroll Calendar Notes",
            "value": "ALL",
            "placeholder": "Payroll Calendar Notes",
            "class": "col-md-12",
            "type": "textarea",
            "dataType" : "string",
            "tooltip" : "Max 4-digit unique identifier",
            "validators": [
                {
                    "validatorName": "maxlength",
                    "maxLength": 1000,
                    "message": "Maximum length should be 2147483647 characters."
                }
            ]
        },
    ],
};
